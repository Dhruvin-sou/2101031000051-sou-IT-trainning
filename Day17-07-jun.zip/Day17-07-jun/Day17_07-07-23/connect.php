<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $conn = mysqli_connect($servername,$username,$password);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }
    else{
        echo "Connnected Successfully";
    }
?>