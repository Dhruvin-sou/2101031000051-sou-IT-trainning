<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname = "mydb";
    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }

    $sql  = "create table info(id int(5) AUTO_INCREMENT primary key, username varchar(20) , password varchar(20))";
    if(mysqli_query($conn,$sql)){
            echo "table created";
        }
        else{
            echo "error";
    }
?>