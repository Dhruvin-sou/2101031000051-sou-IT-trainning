<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname = "mydb";
    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }

    $sql = "create database myDB";
    if(mysqli_query($conn,$sql)){
        echo "database created";
    }
    else{
        echo "error";
    }
?>