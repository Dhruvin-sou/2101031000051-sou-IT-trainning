﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace feedbackform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name;
            string email;
            string contact;
            string feedback;

            name = Convert.ToString(textBox1.Text);
            email = Convert.ToString(textBox2.Text);
            contact = Convert.ToString(textBox3.Text);
            feedback = Convert.ToString(textBox4.Text);

            label1.Text = Convert.ToString(name);
            label2.Text = Convert.ToString(email);
            label3.Text = Convert.ToString(contact);
            label4.Text = Convert.ToString(feedback);


        }
    }
}
