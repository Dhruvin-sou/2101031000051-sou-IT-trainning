﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter your time");
            int time = Convert.ToInt32(Console.ReadLine());
            if (time < 10)
            {
                Console.WriteLine("Good morning.");
            }
            else if (time < 20 && time > 40)
            {
                Console.WriteLine("Good day.");
            }
            else
            {
                Console.WriteLine("Good evening.");
            }
        }
    }
}
