<!DOCTYPE html>
<html>
<body>

<h1>Day15-5-jun</h1>

<?php
echo "Hello"."<br>"."world";

echo "How are you!";

$a = 10;
$b = 5;

echo "<hr>";

echo "<br>";
echo "the value of a is ". $a;
echo "the value of b is ". $b;

$add;
$sub;
$mul;
$div;

$add = $a + $b;
$sub = $a - $b;
$mul = $a * $b;
$div = $a / $b;

echo "<hr>";

echo "the value of add ". $add. "<br>";
echo "the value of sub ". $sub."<br>";
echo "the value of mul ". $mul. "<br>";
echo "the value of div ". $div. "<br>";


echo "<hr>";

$var = "123abc";
echo "the type of var is " .gettype($var);
settype($var , "int");
echo "<br>";
echo "the type of var is " .gettype($var);

echo "<hr>";

$x=5;
$y=10;

echo ($x > $y) ? ("<br>".$x."is gratest") : ("<br>".$y."is gratest");

if ($x > $y) {
    echo "<br>".$x."is gratest";
  } else {
    echo "<br>".$y."is gratest";
  }

  echo "<hr>";

  $num1=20;
  $num2=15;
  $num3=22;
  if($num1>$num2 && $num1>$num3){
    echo "<br>".$num1;
  }
  else{
    if($num2>$num1 && $num2>$num3){
      echo "<br>".$num2;
    }
    else
      echo "<br>".$num3;
  }

  echo "<hr>";

  for($i=1; $i<=10; $i++){
    echo "<br>".$i;
  }


  echo "<hr>";

  $p=2;
  $q=1;
  while($q<= 10){ 
  echo $p." * ".$q." = ".$p*$q."<br>";
    $q=$q+1;
  }

?>



</body>
</html>

