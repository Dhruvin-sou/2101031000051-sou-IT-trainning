<?php
    $a = 10;
    $b = 20;

    echo "Value of a is : " , $a;
    echo "<br>";
    echo "Value of b is : " , $b;
    echo "<br>";
    echo "Addition is : " , $a+$b;
    echo "<br>";
    echo "Subtraction is : " , $a-$b;
    echo "<br>";
    echo "Multiplication is : " , $a*$b;
    echo "<br>";
    echo "Divition is : " , $a/$b;
    echo "<br>";
?>