<?php
    $name = "Dhruvin gabani";
    $dept = "IT";
    $enroll = 2101031000051;

    echo $name;
    echo "<br>";
    echo $dept;
    echo "<br>";
    echo $enroll;
?>