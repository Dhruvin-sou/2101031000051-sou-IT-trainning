<?php

    $username = $_GET['username'];
    $password = $_GET['password'];

    echo "<br> username: ".$username;
    echo "<br> password: ".$password;
    
?>

