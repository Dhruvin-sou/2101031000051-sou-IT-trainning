<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>

</head>
<body>
    <form id="form1"  name="form1" method="get" action="post.php">

        username : <input type="text" name="username" id="username" />
        password : <input type="password" name="password" id="password" />
        <input type="submit" name="submit" id="submit" />
    </form>
</body>
</html