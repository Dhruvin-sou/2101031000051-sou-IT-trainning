<!DOCTYPE html>
<html>
<body>

<h1>Day16-6-jun</h1>

<?php

$a = array(1,3,5,6,8,11);
print_r($a);


echo "<hr>";

$sum =0;

foreach($a as $val)
{
    $sum = $sum + $val;
}
echo "the value of sum is ".$sum;

echo "<hr>";



$b = array("dhruvin", "sanket", "kenil");
print_r($b);

echo "<br>";

sort($b);
print_r($b);

echo "<hr>";

$merge = array_merge($a , $b);
print_r($merge);

echo "<hr>";

$rev = array_reverse($a);
print_r($rev);

echo "<hr>";

echo "the count of array a is ".count($a);
echo "<br>";
echo "the count of array b is ".count($b);

echo "<hr>";
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
print_r($age);

$c = 250;

echo "<br>".$c;
echo "<br>".abs($c);
echo "<br>".pow(3,3);
echo "<br>".min(42,50,11,9);

$d = 25.452;
echo "<br>".ceil($d);

echo "<hr>";
$e = "welcome by dhruvin gabani";
echo "<br>".$e;
echo "<br>".strlen($e);
echo "<br>".strtoupper($e);
echo "<br>".ord($e);  //pelo akshar w ni asci value return karse
echo "<br>".str_replace("a" , "@", $e);


?>

</body>
</html>

